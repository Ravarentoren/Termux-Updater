# Code of Conduct

We follow a simple rule:
**Be respectful, helpful, and collaborative.**

Harassment or discrimination will not be tolerated.
