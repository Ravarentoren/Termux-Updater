# Changelog

## v1.0.0 — Initial Public Release (2025-11)
- Added Termux-Updater Pro engine
- Added multi-venv update system
- Added conflict detection
- Added JSON reporting
- Added docs (CZ/EN)
