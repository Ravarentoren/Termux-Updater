---
name: Bug report
about: Report a problem with Termux-Updater Pro
---

### Bug Description
(Describe the issue)

### Steps to Reproduce
1.
2.
3.

### Device Info
- Termux version:
- Android version:
- Termux-Updater version:
