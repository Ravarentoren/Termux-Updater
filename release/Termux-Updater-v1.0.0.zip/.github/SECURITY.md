# Security Policy

## Supported Versions
All active releases of Termux-Updater Pro are supported.

## Reporting a Vulnerability
Please open a private GitHub security advisory.
